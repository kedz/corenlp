A python wrapper for the Stanford CoreNLP java library.
